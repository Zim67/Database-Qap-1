INSERT INTO public.books(
	 books_title, author_id, publication_date)
	VALUES ('An Autobiography by Florence  1, '02/19/1999');