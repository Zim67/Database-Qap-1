SELECT title, rental_rate
FROM film
ORDER BY rental_rate DESC;