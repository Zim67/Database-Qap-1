SELECT * FROM public.books
ORDER BY book_id ASC 