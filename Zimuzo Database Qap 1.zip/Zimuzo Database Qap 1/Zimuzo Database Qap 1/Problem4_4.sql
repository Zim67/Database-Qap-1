INSERT INTO public.authors(
   author_name)
	VALUES ('Gregory');