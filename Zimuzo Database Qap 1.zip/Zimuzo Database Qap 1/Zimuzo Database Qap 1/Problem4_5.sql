SELECT * FROM public.authors
ORDER BY author_id ASC 